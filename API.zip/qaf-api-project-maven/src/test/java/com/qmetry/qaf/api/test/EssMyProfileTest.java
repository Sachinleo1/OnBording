package com.qmetry.qaf.api.test;

import java.util.Map;
import org.hamcrest.Matchers;
import org.json.JSONObject;
import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.automation.ws.Response;
import com.qmetry.qaf.automation.ws.RestWSTestCase;

public class EssMyProfileTest extends RestWSTestCase {
	
	@QAFDataProvider(key="ess.details")
	@Test
	public void essMyProfile(Map<String,String> data) 
	{
	
		getWebResource(ConfigurationManager.getBundle().getPropertyValue("essMyProfile")).
		header("Content-Type", "application/json").
		post(ConfigurationManager.getBundle().getPropertyValue("essMyProfile.token"));
		Response response= getResponse();
		JSONObject jsonResponse=new JSONObject(response.getMessageBody());
		JSONObject jsonBody=jsonResponse.getJSONObject("response");
		JSONObject jsonAttributes=jsonBody.getJSONObject("attributes");
		JSONObject jsonAttributes1=jsonBody.getJSONObject("results");
		JSONObject jsonSubAttributes=jsonAttributes1.getJSONObject("user_type");
		JSONObject jsonSubAttributes1=jsonAttributes1.getJSONObject("details");
		JSONObject jsonSubAttributes2=jsonAttributes1.getJSONObject("permission");
		
	
		Validator.verifyThat("TimeStamp ",jsonAttributes.get("timestamp").toString(), Matchers.notNullValue());
		Validator.verifyThat("Expected error code is displayed", jsonAttributes.get("error").toString(),Matchers.equalTo("0")); 
		
		Validator.verifyThat("User type isAdmin ",jsonSubAttributes.get("isAdmin").toString(), Matchers.equalTo("1"));
		Validator.verifyThat("User type editAccess ",jsonSubAttributes.get("edit_access").toString(), Matchers.equalTo("0"));
	
		Validator.verifyThat("Details-Employee Number ",jsonSubAttributes1.get("emp_number").toString(), Matchers.equalTo(data.get("emp_number")));
		Validator.verifyThat("Details-Employee Street1 ",jsonSubAttributes1.get("emp_street1").toString(), Matchers.equalTo(data.get("emp_street1")));
		Validator.verifyThat("Details-Employee Street2 ",jsonSubAttributes1.get("emp_street2").toString(), Matchers.equalTo(data.get("emp_street2")));
		Validator.verifyThat("Details-Employee city code ",jsonSubAttributes1.get("city_code").toString(), Matchers.equalTo(data.get("city_code")));
		Validator.verifyThat("Details-Employee Contry Code ",jsonSubAttributes1.get("coun_code").toString(), Matchers.equalTo(data.get("coun_code")));
		Validator.verifyThat("Details-Employee Provin code ",jsonSubAttributes1.get("provin_code").toString(), Matchers.equalTo(data.get("provin_code")));
		Validator.verifyThat("Details-Employee Pin Code ",jsonSubAttributes1.get("emp_zipcode").toString(), Matchers.equalTo(data.get("emp_zipcode")));
		Validator.verifyThat("Details-Employee Street1 Current ",jsonSubAttributes1.get("emp_street1_current").toString(), Matchers.equalTo(data.get("emp_street1_current")));
		Validator.verifyThat("Details-Employee City Code Current ",jsonSubAttributes1.get("city_code_current").toString(), Matchers.equalTo(data.get("city_code_current")));
		Validator.verifyThat("Details-Employee Country Code Current ",jsonSubAttributes1.get("coun_code_current").toString(), Matchers.equalTo(data.get("coun_code_current")));
		Validator.verifyThat("Details-Employee Provin Code Current ",jsonSubAttributes1.get("provin_code_current").toString(), Matchers.equalTo(data.get("provin_code_current")));
		Validator.verifyThat("Details-Employee Zipcode Current ",jsonSubAttributes1.get("emp_zipcode_current").toString(), Matchers.equalTo(data.get("emp_zipcode_current")));
		Validator.verifyThat("Details-Employee Same Address ",jsonSubAttributes1.get("same_address").toString(), Matchers.equalTo(data.get("same_address")));
		Validator.verifyThat("Details-Employee Home Telephone ",jsonSubAttributes1.get("emp_hm_telephone").toString(), Matchers.equalTo(data.get("emp_hm_telephone")));
		Validator.verifyThat("Details-Employee Mobile ",jsonSubAttributes1.get("emp_mobile").toString(), Matchers.equalTo(data.get("emp_mobile")));
		Validator.verifyThat("Details-Employee Work Telephone ",jsonSubAttributes1.get("emp_work_telephone").toString(), Matchers.equalTo(data.get("emp_work_telephone")));
		Validator.verifyThat("Details-Employee Other email ",jsonSubAttributes1.get("emp_oth_email").toString(), Matchers.equalTo(data.get("emp_oth_email")));
		Validator.verifyThat("Details-Employee Bank Name ",jsonSubAttributes1.get("bank_name").toString(), Matchers.equalTo(data.get("bank_name")));
		Validator.verifyThat("Details-Employee Account No ",jsonSubAttributes1.get("account_no").toString(), Matchers.equalTo(data.get("account_no")));
		Validator.verifyThat("Details-Employee PF No ",jsonSubAttributes1.get("pfno").toString(), Matchers.equalTo(data.get("pfno")));
		Validator.verifyThat("Details-Employee UN No ",jsonSubAttributes1.get("un_no").toString(), Matchers.equalTo(data.get("un_no")));
		Validator.verifyThat("Details-Employee Mail Sent ",jsonSubAttributes1.get("mail_sent").toString(), Matchers.equalTo(data.get("mail_sent")));
		Validator.verifyThat("Details-Employee Country ",jsonSubAttributes1.get("country").toString(), Matchers.equalTo(data.get("country")));
		Validator.verifyThat("Details-Employee Country Current ",jsonSubAttributes1.get("country_current").toString(), Matchers.equalTo(data.get("country_current")));
		
		
		Validator.verifyThat("Permission-Edit Contact Details ",jsonSubAttributes2.get("edit_contact_details").toString(), Matchers.equalTo("1"));
		Validator.verifyThat("Permission-Get Contact Details ",jsonSubAttributes2.get("get_contact_details").toString(), Matchers.equalTo("1"));
		Validator.verifyThat("Permission- Declare Relationship ",jsonSubAttributes2.get("declare_relationship").toString(), Matchers.equalTo("1"));
	
		}

}

