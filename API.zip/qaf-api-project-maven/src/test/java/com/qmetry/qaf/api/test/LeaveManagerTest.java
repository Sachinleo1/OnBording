package com.qmetry.qaf.api.test;

import java.util.HashMap;
import java.util.Map;
import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.automation.ws.Response;
import com.qmetry.qaf.automation.ws.RestWSTestCase;

public class LeaveManagerTest extends RestWSTestCase {

	@Test
	public void leaveManager() 
	{
	
		getWebResource(ConfigurationManager.getBundle().getPropertyValue("leaveManager")).
		header("Content-Type", "application/json").
		post(ConfigurationManager.getBundle().getPropertyValue("leaveManager.token"));
		Response response= getResponse();
		JSONObject jsonResponse=new JSONObject(response.getMessageBody());
		JSONObject jsonBody=jsonResponse.getJSONObject("response");
		JSONObject jsonAttributes=jsonBody.getJSONObject("attributes");
		JSONArray leaveManagerArray=jsonBody.getJSONArray("results");	
	
		Map<String, String> LeaveManagerActual=new HashMap<>();
		for(int i=0;i<leaveManagerArray.length();i++) {
			JSONObject obj=leaveManagerArray.getJSONObject(i);
			LeaveManagerActual.put(obj.get("holiday_id").toString(),obj.getString("description"));
		}
		
		
		Map<String, String> LeaveManagerExpected=new HashMap<>();
		String source=ConfigurationManager.getBundle().getPropertyValue("leaveManager.result");
		JSONArray expected=new JSONArray(source);
		for(int i=0;i<expected.length();i++) {
			JSONObject obj=expected.getJSONObject(i);
			LeaveManagerExpected.put(obj.get("holiday_id").toString(),obj.getString("description"));
		}
		
		Validator.verifyThat(jsonAttributes.get("timestamp").toString(), Matchers.notNullValue());
		Validator.verifyThat("Expected error code is displayed", jsonAttributes.get("error").toString(),Matchers.equalTo("0")); 
		Validator.verifyThat(LeaveManagerActual, Matchers.equalTo(LeaveManagerExpected));
		
		}

}