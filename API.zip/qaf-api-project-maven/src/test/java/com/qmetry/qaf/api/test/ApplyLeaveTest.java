package com.qmetry.qaf.api.test;

import java.util.HashMap;
import java.util.Map;
import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.automation.ws.Response;
import com.qmetry.qaf.automation.ws.RestWSTestCase;

public class ApplyLeaveTest extends RestWSTestCase {
	
	@Test
	public void applyLeaveTest() {
	
		getWebResource(ConfigurationManager.getBundle().getPropertyValue("applyLeave")).
		header("Content-Type", "application/json").
		post(ConfigurationManager.getBundle().getPropertyValue("leave.token"));
		Response response= getResponse();
		JSONObject jsonResponse=new JSONObject(response.getMessageBody());
		JSONObject jsonBody=jsonResponse.getJSONObject("response");
		JSONObject jsonAttributes=jsonBody.getJSONObject("attributes");
		JSONArray leaveTypesArray=jsonBody.getJSONArray("results");		
		
		
		Map<String, String> leaveTypes=new HashMap<>();
		for(int i=0;i<leaveTypesArray.length();i++) {
			JSONObject obj=leaveTypesArray.getJSONObject(i);
			leaveTypes.put(obj.get("leaveid").toString(),obj.getString("reason"));
		}
		
		
		Map<String, String> expectedLeaveTypes=new HashMap<>();
		String source=ConfigurationManager.getBundle().getPropertyValue("body.reason");
		JSONArray expected=new JSONArray(source);
		for(int i=0;i<expected.length();i++) {
			JSONObject obj=expected.getJSONObject(i);
			expectedLeaveTypes.put(obj.get("leaveid").toString(),obj.getString("reason"));
		}
		
		Validator.verifyThat(jsonAttributes.get("timestamp").toString(), Matchers.notNullValue());
		Validator.verifyThat("Expected error code is displayed", jsonAttributes.get("error").toString(),Matchers.equalTo("0")); 
		Validator.verifyThat(leaveTypes, Matchers.equalTo(expectedLeaveTypes));
		
	}

}
