package com.qmetry.qaf.api.test;

import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.automation.ws.Response;
import com.qmetry.qaf.automation.ws.RestWSTestCase;

public class VisaRequestTest extends RestWSTestCase {
	@Test
	public void visaRequest() {
	
		getWebResource(ConfigurationManager.getBundle().getPropertyValue("visaRequest")).
		header("Content-Type", "application/json").
		post(ConfigurationManager.getBundle().getPropertyValue("visa.token"));
		Response response= getResponse();
		JSONObject jsonResponse=new JSONObject(response.getMessageBody());
		JSONObject jsonBody=jsonResponse.getJSONObject("response");
		JSONObject jsonAttributes=jsonBody.getJSONObject("attributes");
		JSONArray visaRequestArray=jsonBody.getJSONArray("results");		
		
		
		Map<String, String> visaRequestActual=new HashMap<>();
		for(int i=0;i<visaRequestArray.length();i++) {
			JSONObject obj=visaRequestArray.getJSONObject(i);
			visaRequestActual.put(obj.get("emp_number").toString(),obj.getString("ename"));
		}
		
		
		Map<String, String> visaRequestExpected=new HashMap<>();
		String source=ConfigurationManager.getBundle().getPropertyValue("visa.result");
		JSONArray expected=new JSONArray(source);
		for(int i=0;i<expected.length();i++) {
			JSONObject obj=expected.getJSONObject(i);
			visaRequestExpected.put(obj.get("emp_number").toString(),obj.getString("ename"));
		}
		
		Validator.verifyThat(jsonAttributes.get("timestamp").toString(), Matchers.notNullValue());
		Validator.verifyThat("Expected error code is displayed", jsonAttributes.get("error").toString(),Matchers.equalTo("0")); 
		Validator.verifyThat(visaRequestActual, Matchers.equalTo(visaRequestExpected));
		
	}

}