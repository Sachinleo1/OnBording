package com.qmetry.qaf.appium.test;

import java.util.Map;
import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.appium.pages.VerifySearchAndFilterPage;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifySearchAndFilterTest extends WebDriverTestBase{
	
	@QAFDataProvider(key="search.filter")
	@Test
	public void verifySearchAndFilter(Map<String,String> data)
	{
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 	
		VerifySearchAndFilterPage filter=new VerifySearchAndFilterPage();
		filter.searchFilter(data.get("productName"));
		
	}

}
