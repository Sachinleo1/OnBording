package com.qmetry.qaf.apppium.utility;

import org.openqa.selenium.Dimension;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.offset.PointOption; 
 




public class Utility extends WebDriverTestBase {

	
	@SuppressWarnings("all")
    public AndroidDriver getAndroidDriver() {
 
		AndroidDriver  driver = (AndroidDriver) getDriver().getUnderLayingDriver();
        return driver;
 
    }
//	
//	public void scrollUp()//(double startPercentage, double finalPercentage, int duration) {
//	{ 
//        @SuppressWarnings("all")
//        AppiumDriver driver = getAndroidDriver();
// 
//        Dimension dim = driver.manage().window().getSize();
// 
//        int width = (int) (dim.width/ 2);
//        int startPoint = (int) (dim.getHeight() * 0.12);//startPercentage);
//        int endPoint = (int) (dim.getHeight() *0.16);// finalPercentage);
// 
//        @SuppressWarnings("all")
//        TouchAction act = new TouchAction(driver);
//        act.press(PointOption.point(width, startPoint)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(100)))
//                .moveTo(PointOption.point(width, endPoint)).release().perform();
// 
//    }
	
	public  void scrollVertical()
	{
		Dimension size=getAndroidDriver().manage().window().getSize();
		int startXpoint=size.getWidth()/2;
		int startYpoint=size.getHeight()/2;
		int endXpoint=startXpoint;
		int endYpoint=(int)(startYpoint*0.60);
		AndroidTouchAction touch=new AndroidTouchAction(getAndroidDriver());
		touch.longPress(PointOption.point(startXpoint,startYpoint)).moveTo(PointOption.point(endXpoint, endYpoint)).release().perform();
		
		
	}
	
	
	

}
