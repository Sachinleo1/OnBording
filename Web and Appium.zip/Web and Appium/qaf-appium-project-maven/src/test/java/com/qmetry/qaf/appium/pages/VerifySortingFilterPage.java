package com.qmetry.qaf.appium.pages;

import java.util.List;

import com.qmetry.qaf.apppium.utility.Utility;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class VerifySortingFilterPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="Verify.SearchProduct.searchBar")
	private QAFWebElement searchBar;
	@FindBy(locator="Verify.SearchProduct.displayedProduct")
	private QAFWebElement displayedProduct;
	@FindBy(locator="Verify.SearchProduct.home")
	private QAFWebElement home;
	@FindBy(locator="verify.search.filterDropDown")
	private QAFWebElement filterDropDown;
	@FindBy(locator="verify.search.sortMenu")
	private QAFWebElement sortMenu;
	@FindBy(locator="verify.search.sortLowToHigh")
	private QAFWebElement sortLowToHigh;
	@FindBy(locator="verify.search.price")
	private List<QAFWebElement> price;
	
	public QAFWebElement getSearchBar() {
		return searchBar;
	}
	public QAFWebElement getDisplayedProduct() {
		return displayedProduct;
	}
	public QAFWebElement getHome() {
		return home;
	}
	public QAFWebElement getFilterDropDown() {
		return filterDropDown;
	}
	public QAFWebElement getSortMenu() {
		return sortMenu;
	}
	public QAFWebElement getSortLowToHigh() {
		return sortLowToHigh;
	}
	public List<QAFWebElement> getPrice() {
		return price;
	}

	public void sortingFilter(String productName)
	{
		Utility scroll=new Utility();
		getHome().click();
		Validator.assertTrue(getSearchBar().isPresent(), "Search Bar is Not present", "SearchBar is present");
		getSearchBar().click();
		getSearchBar().sendKeys(productName+"\n");
		scroll.scrollVertical();
		getFilterDropDown().waitForVisible(5000);
		for(int i=0;i<2;i++)
		{
			Reporter.log("Before Sorting Price Was= "+ getPrice().get(i).getText());
		}
	
		getFilterDropDown().click();
		getSortMenu().click();
		getSortLowToHigh().click();
		Reporter.logWithScreenShot("Selecting Sorting Type");
		driver.navigate().back();
		for(int i=0;i<2;i++)
		{
			Reporter.log("After Sorting Price is= "+ getPrice().get(i).getText());
		}
	}
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
