package com.qmetry.qaf.appium.test;

import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.VerifyAddToCartPage;
import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifyAddToCartTest extends WebDriverTestBase {
	
	@Test
	public void VerifyAddToCart()
	{
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 
		
		VerifyAddToCartPage cart=new VerifyAddToCartPage();
		cart.addToCart();
	}

}
