package com.qmetry.qaf.appium.pages;

import com.qmetry.qaf.appium.components.VerifyOnSearchProductComponent;
import com.qmetry.qaf.apppium.utility.Utility;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import java.util.List;

public class VerifyOnSearchProductPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="Verify.SearchProduct.searchBar")
	private QAFWebElement searchBar;
	@FindBy(locator="Verify.SearchProduct.displayedProduct")
	private QAFWebElement displayedProduct;
	@FindBy(locator="Verify.SearchProduct.home")
	private QAFWebElement home;
	
	@FindBy(locator="Verify.SearchProduct.content")
	private List<VerifyOnSearchProductComponent> productContent;
	
	
	public QAFWebElement getSearchBar() {
		return searchBar;
	}

	public QAFWebElement getDisplayedProduct() {
		return displayedProduct;
	}
	public QAFWebElement getHome() {
		return home;
	}
	public List<VerifyOnSearchProductComponent> getProductContent() {
		return productContent;
	}
	static Utility scroll=new Utility();
	public void search(String productName)
	{
		getHome().click();
		Validator.assertTrue(getSearchBar().isPresent(), "Search Bar is Not present", "SearchBar is present");
		getSearchBar().click();
		getSearchBar().sendKeys(productName+"\n");
		scroll.scrollVertical();
		Reporter.logWithScreenShot("Search Result");
		scroll.scrollVertical();
		scroll.scrollVertical();
		String[] split=productName.split(" ");
		for (int i=0;i<4;i++)
			{ 
			if(getProductContent().get(i).getProductDescription().getText().contains(split[0])){
			Reporter.logWithScreenShot(" Product Title=   " +getProductContent().get(i).getProductTitle().getText() +"  Product Description=  "+ getProductContent().get(i).getProductDescription().getText());
		}
			else
			{
				Reporter.logWithScreenShot("Wrong Product on search "+" Product Title=   " +getProductContent().get(i).getProductTitle().getText() +"  Product Description=  "+ getProductContent().get(i).getProductDescription().getText());
			}
		}}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
