package com.qmetry.qaf.appium.pages;

import java.util.List;

import com.qmetry.qaf.appium.components.VerifyOnSearchProductComponent;
import com.qmetry.qaf.apppium.utility.Utility;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class VerifySearchAndFilterPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="Verify.SearchProduct.searchBar")
	private QAFWebElement searchBar;
	@FindBy(locator="Verify.SearchProduct.displayedProduct")
	private QAFWebElement displayedProduct;
	@FindBy(locator="Verify.SearchProduct.home")
	private QAFWebElement home;
	@FindBy(locator="verify.search.filterDropDown")
	private QAFWebElement filterDropDown;
	@FindBy(locator="verify.search.format")
	private QAFWebElement format;
	@FindBy(locator="verify.search.paperback")
	private QAFWebElement paperback;
	
	@FindBy(locator="Verify.SearchProduct.content")
	private List<VerifyOnSearchProductComponent> productContent;
	
	public QAFWebElement getSearchBar() {
		return searchBar;
	}
	public QAFWebElement getDisplayedProduct() {
		return displayedProduct;
	}
	public QAFWebElement getHome() {
		return home;
	}
	public QAFWebElement getFilterDropDown() {
		return filterDropDown;
	}
	public QAFWebElement getFormat() {
		return format;
	}
	public QAFWebElement getPaperback() {
		return paperback;
	}
	public List<VerifyOnSearchProductComponent> getProductContent() {
		return productContent;
	}
	
	static Utility scroll=new Utility();
	public void searchFilter(String productName)
	{
		getHome().click();
		Validator.assertTrue(getSearchBar().isPresent(), "Search Bar is Not present", "SearchBar is present");
		getSearchBar().click();
		getSearchBar().sendKeys(productName+"\n");
		getFilterDropDown().waitForVisible(5000);
		getFilterDropDown().click();
		scroll.scrollVertical();
		getFormat().click();
		getPaperback().click();
		String edition=getPaperback().getText();
		driver.navigate().back();
		scroll.scrollVertical();
		scroll.scrollVertical();
		for (int i=0;i<4;i++)
		{ 
			if(getProductContent().get(i).getEdition().getText().contains(edition)){
				Reporter.logWithScreenShot(" Product Title=   " +getProductContent().get(i).getProductDescription().getText() +"  Format=  "+ getProductContent().get(i).getEdition().getText());
			}
			else
			{
				Reporter.logWithScreenShot("Wrong Result on Filter:  Product Title=   " +getProductContent().get(i).getProductDescription().getText() +"  Format=  "+ getProductContent().get(i).getEdition().getText());
			}
		}
		
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
	}
}


















