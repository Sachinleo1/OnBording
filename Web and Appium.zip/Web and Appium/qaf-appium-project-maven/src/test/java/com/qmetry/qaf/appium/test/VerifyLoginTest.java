package com.qmetry.qaf.appium.test;

import org.testng.annotations.Test;

import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifyLoginTest extends WebDriverTestBase {
	
	@Test
	public void verifySignIn()
	{
	VerifyLoginPage login=new VerifyLoginPage();
	login.signIn();
	}
}
