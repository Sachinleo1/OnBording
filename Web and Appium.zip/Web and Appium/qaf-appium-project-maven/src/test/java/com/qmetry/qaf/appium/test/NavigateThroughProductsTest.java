package com.qmetry.qaf.appium.test;

import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.NavigateThroughProductsPage;
import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class NavigateThroughProductsTest extends WebDriverTestBase {
	
	@Test
	public void NavigateThroughProducts()
	{
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 
		
		NavigateThroughProductsPage products=new NavigateThroughProductsPage();
		products.selectProducts();
	}

}
