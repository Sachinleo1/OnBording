package com.qmetry.qaf.appium.test;

import java.util.Map;
import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.appium.pages.VerifyOnSearchProductPage;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifyRelevantProductSearch extends WebDriverTestBase{
	
	@QAFDataProvider(key="search.relevantproduct")
	@Test(description="Verification on Relevant Product Search")
	public void VerifyOnRelevantProduct(Map<String,String> data)
	{
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 	
		VerifyOnSearchProductPage searchProduct=new VerifyOnSearchProductPage();
		searchProduct.search(data.get("productName"));
	}


}
