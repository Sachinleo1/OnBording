package com.qmetry.qaf.appium.test;

import java.util.Map;
import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.appium.pages.VerifyOnSearchProductPage;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifyOnSearchProductTest extends WebDriverTestBase{
	@QAFDataProvider(key="search.product")
	@Test
	public void VerifyOnSearchProduct(Map<String,String> data)
	{
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 	
		VerifyOnSearchProductPage searchProduct=new VerifyOnSearchProductPage();
		searchProduct.search(data.get("productName"));
	}

}
