package com.qmetry.qaf.appium.test;

import java.util.Map;

import org.testng.annotations.Test;

import com.qmetry.qaf.appium.pages.VerifyLoginPage;
import com.qmetry.qaf.appium.pages.VerifySortingFilterPage;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class VerifySortingFilterTest extends WebDriverTestBase {
	
	@QAFDataProvider(key="search.filter")
	@Test
	public void VerifySortingFilter(Map<String,String> data) {
		
		VerifyLoginPage login=new VerifyLoginPage();
		login.signIn(); 
		
		VerifySortingFilterPage sort=new VerifySortingFilterPage();
		sort.sortingFilter(data.get("productName"));
	
}
}
