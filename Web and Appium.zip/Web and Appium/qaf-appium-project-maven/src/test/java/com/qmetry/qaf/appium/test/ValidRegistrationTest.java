package com.qmetry.qaf.appium.test;

import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.ValidRegistrationPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class ValidRegistrationTest extends WebDriverTestBase {
	
	
	@Test
	public void verifyRegistration()
	{
		ValidRegistrationPage registration = new ValidRegistrationPage();
		registration.register();
	}

}
