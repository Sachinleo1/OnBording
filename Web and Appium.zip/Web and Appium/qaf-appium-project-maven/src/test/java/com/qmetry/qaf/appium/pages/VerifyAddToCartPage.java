package com.qmetry.qaf.appium.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.apppium.utility.Utility;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class VerifyAddToCartPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="navigate.products.hamBurger.btn")
	private QAFWebElement hamBurgerMenu;
	@FindBy(locator="navigate.products.home")
	private QAFWebElement home;
	@FindBy(locator="navigate.products.category")
	private QAFWebElement category;
	@FindBy(locator="navigate.products.MensFashion")
	private QAFWebElement mensFashion;
	@FindBy(locator="navigate.products.AmazonFashion")
	private QAFWebElement amazonFashion;
	@FindBy(locator="navigate.products.men")
	private QAFWebElement men;
	@FindBy(locator="navigate.products.clothing")
	private QAFWebElement clothing;
	@FindBy(locator="navigate.products.tShirtsCatogry")
	private QAFWebElement tShirtsCatogry;
	@FindBy(locator="navigate.products.tshirt1")
	private QAFWebElement tshirt1;
	@FindBy(locator="navigate.products.tshirt2")
	private QAFWebElement tshirt2;
	@FindBy(locator="navigate.products.tshirt3")
	private QAFWebElement tshirt3;
	@FindBy(locator="navigate.products.tShirt.details")
	private QAFWebElement tshirtDetails;
	
	@FindBy(locator="verify.addToCart.productTitle")
	private QAFWebElement productTitle;
	@FindBy(locator="verify.addToCart.sizeBtn")
	private QAFWebElement sizeBtn;
	@FindBy(locator="verify.addToCart.size")
	private QAFWebElement size;
	@FindBy(locator="verify.addToCart.popUp")
	private QAFWebElement popUp;
	@FindBy(locator="verify.addToCart.addToCart")
	private QAFWebElement addToCartBtn;
	@FindBy(locator="verify.addToCart.tostMsg")
	private QAFWebElement tostMsg;
	@FindBy(locator="verify.addToCart.viewcart")
	private QAFWebElement viewcart;
	@FindBy(locator="verify.addToCart.inCart")
	private QAFWebElement inCart;
	
	
	
	public QAFWebElement getHamBurgerMenu() {
		return hamBurgerMenu;
	}
	public QAFWebElement getHome() {
		return home;
	}
	public QAFWebElement getCategory() {
		return category;
	}
	public QAFWebElement getMensFashion() {
		return mensFashion;
	}
	public QAFWebElement getAmazonFashion() {
		return amazonFashion;
	}
	public QAFWebElement getMen() {
		return men;
	}
	public QAFWebElement getClothing() {
		return clothing;
	}
	public QAFWebElement gettShirtsCatogry() {
		return tShirtsCatogry;
	}
	public QAFWebElement getTshirt1() {
		return tshirt1;
	}
	public QAFWebElement getTshirt2() {
		return tshirt2;
	}
	public QAFWebElement getTshirt3() {
		return tshirt3;
	}
	public QAFWebElement getTshirtDetails() {
		return tshirtDetails;
	}
	
	public QAFWebElement getProductTitle() {
		return productTitle;
	}
	public QAFWebElement getSizeBtn() {
		return sizeBtn;
	}
	public QAFWebElement getSize() {
		return size;
	}
	public QAFWebElement getPopUp() {
		return popUp;
	}
	public QAFWebElement getAddToCartBtn() {
		return addToCartBtn;
	}
	public QAFWebElement getTostMsg() {
		return tostMsg;
	}
	public QAFWebElement getViewcart() {
		return viewcart;
	}
	public QAFWebElement getInCart() {
		return inCart;
	}



static Utility scroll=new Utility();

private void nagivateToProduct()
{
	//Utility scroll=new Utility();
	
	getCategory().waitForVisible(10000);
	getCategory().click();
	getMensFashion().click();
	scroll.scrollVertical();
	Reporter.logWithScreenShot("Selected Category is :");
	
	getAmazonFashion().click();
	getMen().click();
	getClothing().click();
	scroll.scrollVertical();
	gettShirtsCatogry().click();
	
}

public void cart()
{
	
	scroll.scrollVertical();
	Reporter.logWithScreenShot("Selected Product is :");
	getSizeBtn().click();
	getSize().click();
	getPopUp().click();
	scroll.scrollVertical();	
	getAddToCartBtn().click();
	scroll.scrollVertical();
	Reporter.logWithScreenShot("product added to cart");
	getTshirtDetails().waitForVisible(5000);
	Validator.verifyThat("Product Details page is displayed", getTshirtDetails().getText(),Matchers.containsString("About this item"));
	getViewcart().click();
	getInCart().waitForVisible(10000);
	
}
	public void addToCart()
	{ 
		//Product one
		nagivateToProduct();
		getTshirt1().waitForVisible(10000);
		getTshirt1().click();
		Reporter.logWithScreenShot("Adding to cart= "+getProductTitle().getText());
		String Tshirt1 =getProductTitle().getText();
		cart();
		Validator.verifyThat("Product is Displayed IN CART", Tshirt1,Matchers.containsString(getInCart().getText()));
		
		
		//Product two
		getHamBurgerMenu().click();
		nagivateToProduct();
		getTshirt2().click();
		Reporter.logWithScreenShot("Adding to cart= "+getProductTitle().getText());
		String Tshirt2 =getProductTitle().getText();
		cart();
		Validator.verifyThat("Product is Displayed IN CART", Tshirt2 ,Matchers.containsString(getInCart().getText()));
		
		
		//Product three
		getHamBurgerMenu().click();
		nagivateToProduct();
		scroll.scrollVertical();	
		getTshirt3().click();
		Reporter.logWithScreenShot("Adding to cart= "+getProductTitle().getText());
		String Tshirt3 =getProductTitle().getText();
		cart();
		Validator.verifyThat("Product is Displayed IN CART", Tshirt3,Matchers.containsString(getInCart().getText()));
	}



	




	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}


}
