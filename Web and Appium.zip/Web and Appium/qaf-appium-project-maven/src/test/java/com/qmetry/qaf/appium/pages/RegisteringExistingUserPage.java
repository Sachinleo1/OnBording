package com.qmetry.qaf.appium.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.appium.beans.RandomCreateAccountDataBeans;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class RegisteringExistingUserPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	@FindBy(locator="registration.skip.signIn.btn")
	private QAFWebElement skipSinginBtn;
	@FindBy(locator="registration.hamBurger.btn")
	private QAFWebElement hamBurgerMenu;
	@FindBy(locator="registration.hello.signIn.link")
	private QAFWebElement signIn;
	@FindBy(locator="registration.create.acount.radioBtn")
	private QAFWebElement createAccountBtn;
	@FindBy(locator="registration.name.text")
	private QAFWebElement name;
	@FindBy(locator="registration.phoneNumber")
	private QAFWebElement phoneNumber;
	@FindBy(locator="registration.email")
	private QAFWebElement email;
	@FindBy(locator="registration.set.password")
	private QAFWebElement password;
	@FindBy(locator="registration.continue.btn")
	private QAFWebElement continueBtn;
	@FindBy(locator="registration.error.msg")
	private QAFWebElement errorMsg;
	
	
	public QAFWebElement getSkipSinginBtn() {
		return skipSinginBtn;
	}
	public QAFWebElement getHamBurgerMenu() {
		return hamBurgerMenu;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getCreateAccountBtn() {
		return createAccountBtn;
	}
	public QAFWebElement getName() {
		return name;
	}
	public QAFWebElement getPhoneNumber() {
		return phoneNumber;
	}
	public QAFWebElement getEmail() {
		return email;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getContinueBtn() {
		return continueBtn;
	}
	public QAFWebElement getErrorMsg() {
		return errorMsg;
	}
	public void register(String name,String phoneNumber,String email,String password)
	{	
	
		getSkipSinginBtn().click();
		Validator.assertTrue(getHamBurgerMenu().isDisplayed(), "hamburger menu is not present", "hamburger menu is present");
		getHamBurgerMenu().click();
		Validator.assertTrue(getSignIn().isPresent(), "SignIn link is Not present in left menu", "SignIn link is present in left menu");
		getSignIn().click();
		Validator.assertTrue(getCreateAccountBtn().isDisplayed(), "Create Account Btn is not present", "Create Account Btn is present");
		getCreateAccountBtn().click();
		Validator.assertTrue(getName().isPresent(), "Name Field is Not present", "Name Field is present");
		
		RandomCreateAccountDataBeans formData = new RandomCreateAccountDataBeans();
		formData.fillRandomData();
		
		getName().sendKeys(name);
		Reporter.logWithScreenShot(getName().getText());
		Validator.assertTrue(getPhoneNumber().isPresent(), "Phone Number Field is Not present", "Phone Number Field is present");
		getPhoneNumber().sendKeys(phoneNumber);
		Reporter.logWithScreenShot(getPhoneNumber().getText());
		Validator.assertTrue(getEmail().isPresent(), "Email Field is Not present", "Email Field is present");
		getEmail().sendKeys(email);
		Reporter.logWithScreenShot(getEmail().getText());
		Validator.assertTrue(getPassword().isPresent(), "Password Field is Not present", "Password Field is present");
		getPassword().sendKeys(password);
		Reporter.logWithScreenShot(password);
		Validator.assertTrue(getContinueBtn().isPresent(), "Continue Btn is not present", "Continue Btn is present");
		getCreateAccountBtn().click();
		getCreateAccountBtn().click();
		getContinueBtn().click();
		Reporter.logWithScreenShot("clicking on continue btn");
		getErrorMsg().waitForVisible(10000);
		Validator.verifyThat("account already exists with the mobile phone number",getErrorMsg().getText(),Matchers.containsString("You indicated you are a new customer, but an account already exists with the mobile phone number"));
		
	}
	
	public void skipSignIn()
	{
		getSkipSinginBtn().click();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}



