package com.qmetry.qaf.appium.test;

import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.appium.pages.RegisteringExistingUserPage;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;

public class RegisteringExistingUserTest extends WebDriverTestBase {
	
	@QAFDataProvider(key="existing.user")
	@Test
	public void verifyExistingUserRegistration(Map<String,String> data)
	{
		RegisteringExistingUserPage registration = new RegisteringExistingUserPage();
		registration.register(data.get("name"),data.get("phoneNumber"),data.get("email"),data.get("password"));
	}

}
