package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;

public class VerifyPopUpPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	
	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	@FindBy(locator="verify.pop.up.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	@FindBy(locator="verify.pop.up.selectFlightContinueBtn")
	private QAFWebElement selFlightContBtn;
	@FindBy(locator="verify.pop.up.countryDropDown")
	private QAFWebElement countryDropDown;
	
	
	
	
	
	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getSelFlightContBtn() {
		return selFlightContBtn;
	}
	public QAFWebElement getCountryDropDown() {
		return countryDropDown;
	}
	
	public void verifyLoginPageTitle(){
		Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		}
	public void login(){
		
		getUserName().sendKeys(ConfigurationManager.getBundle().getString("test.user.name"));
		getPassword().sendKeys(ConfigurationManager.getBundle().getString("test.pass.password"));
		getSignIn().click();
		Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		}
	
	public void verifyPopUpMsg(){
	
		getFndFlightContBtn().click();
		getSelFlightContBtn().click();
		Validator.verifyThat("Book a Flight Page", driver.getTitle(),Matchers.containsString("Book a Flight: Mercury Tours"));
		Select country=new Select(getCountryDropDown());
		String selectCountry="INDIA";
		if(selectCountry!="UNITED STATES")
		{
			country.selectByVisibleText(selectCountry);
			Validator.verifyThat("Pop Up Message", driver.switchTo().alert().getText(),Matchers.containsString("You have chosen a mailing location outside of the United States and its territories. An additional charge of $6.5 will be added as mailing charge."));
			driver.switchTo().alert().accept();	
			WebElement option = country.getFirstSelectedOption();
			Validator.verifyThat("Selected Country Value", option.getText(),Matchers.containsString("INDIA"));
		}

	    }
	
	
	
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
