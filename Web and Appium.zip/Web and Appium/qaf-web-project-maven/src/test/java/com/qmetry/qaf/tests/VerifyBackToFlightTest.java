package com.qmetry.qaf.tests;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.VerifyBackToFlightPage;

public class VerifyBackToFlightTest extends WebDriverTestBase {
	
	@Test
	public void VerifyBackToFlight()
	{
		VerifyBackToFlightPage flight= new VerifyBackToFlightPage();
		flight.launchPage(null);
		flight.verifyLoginPageTitle();
		flight.login();
		flight.verifyFlightConformationPage();
		
		
	}
	

}
