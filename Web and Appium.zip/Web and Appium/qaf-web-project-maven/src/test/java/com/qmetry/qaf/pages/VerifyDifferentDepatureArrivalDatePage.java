package com.qmetry.qaf.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class VerifyDifferentDepatureArrivalDatePage extends WebDriverBaseTestPage<WebDriverTestPage> {

	VerifyBackToFlightPage flight= new VerifyBackToFlightPage();
	@FindBy(locator="validate.departureArrivalDate.fromDate")
	private QAFWebElement fromDate;
	@FindBy(locator="validate.departureArrivalDate.toDate")
	private QAFWebElement toDate;
	@FindBy(locator="validate.departureArrivalDate.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	
	public QAFWebElement getFromDate() {
		return fromDate;
	}
	public QAFWebElement getToDate() {
		return toDate;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}

	public void findFlight(String departDate,String arrivingDate)
	{
		
		//If Departure date is past day it takes -1 and reduce one day from current date
		if(departDate.equals("-1"))
		{
			
			Select futureDate=new Select(getFromDate());
			futureDate.selectByVisibleText(pastDate(departDate));
			Reporter.log("Departure Date is:"+pastDate(departDate));
			
		}
		//else Departure date is next day it takes 1 and add one day from current date
		else
		{
			Select futureDate=new Select(getFromDate());
			futureDate.selectByVisibleText(futureDate(departDate));
			Reporter.log("Departure Date is:"+futureDate(departDate));
			
		}
	
		//If Arrival date is past day it takes -1 and reduce one day from current date
		 if(arrivingDate.equals("-1"))
		{
			Select arrivalDate=new Select(getToDate());
			arrivalDate.selectByVisibleText(pastDate(arrivingDate));
			Reporter.log("Arrival In Date is:"+pastDate(arrivingDate));
		}
		//else Arrival date is next day it takes 1 and add one day from current date
		else
		{
			Select arrivalDate=new Select(getToDate());
			arrivalDate.selectByVisibleText(futureDate(arrivingDate));
			Reporter.log("Arrival In Date is:"+futureDate(arrivingDate));
			}
		
		Validator.assertThat("Find a Flight Page",driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		getFndFlightContBtn().click();
		Validator.assertThat("Select a Flight Page",driver.getTitle(),Matchers.containsString("Select a Flight: Mercury Tours"));
		flight.getSelFlightContBtn().click();
		flight.getSecurePurchaseBtn().click();
		Validator.verifyThat("Flight Conformation Page", driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		flight.getBackToFlightBtn().click();
		Validator.verifyThat("Back to Flight Finder Page", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		
	}
	
	
	// This function is used to calculate Future day
	public String futureDate(String futureDate)
	{
	
		SimpleDateFormat formatter = new SimpleDateFormat("dd");
		Date date = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int calculate = Integer.parseInt(futureDate);
		c.add(Calendar.DATE,calculate);
		date = c.getTime();
		String future = formatter.format(date);
		future=StringUtils.stripStart(future,"0");
		return future;
	}
	// This function is used to calculate Past day
	public String pastDate(String pastDate)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("dd");
		Date date = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int calculate = Integer.parseInt(pastDate);
		c.add(Calendar.DATE,calculate);
		date = c.getTime();
		String past = formatter.format(date);
		past=StringUtils.stripStart(past,"0");
		return past;
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
