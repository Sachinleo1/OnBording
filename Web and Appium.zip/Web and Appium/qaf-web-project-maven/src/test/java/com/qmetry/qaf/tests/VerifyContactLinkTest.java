package com.qmetry.qaf.tests;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.VerifyContactPage;


public class VerifyContactLinkTest extends WebDriverTestBase {
	
	
	@Test
	public void verify_contactLink()
	{
		VerifyContactPage contactPage=new VerifyContactPage();
		contactPage.launchPage(null);
		contactPage.verifyContLink();
		contactPage.getContactLink().click();
		contactPage.underConMsg();
		contactPage.getBack2home().click();
		contactPage.homepage();
	}
	
}
