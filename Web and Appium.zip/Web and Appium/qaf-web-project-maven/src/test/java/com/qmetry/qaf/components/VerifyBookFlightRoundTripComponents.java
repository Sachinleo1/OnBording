package com.qmetry.qaf.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class VerifyBookFlightRoundTripComponents extends QAFWebComponent {

	public VerifyBookFlightRoundTripComponents(String locator) {
		super(locator);
	}
	
	@FindBy(locator="flight.roundtrip.book.radiobtn.departFlight")
	private QAFWebElement departFlightRadioBtn;
	
	@FindBy(locator="flight.roundtrip.book.radiobtn.returnflight")
	private QAFWebElement returnflightRadioBtn;
	
	@FindBy(locator="flight.roundtrip.book.name.departflightdetails")
	private QAFWebElement departFlightName;
	
	@FindBy(locator="flight.roundtrip.book.name.returnflightdetails")
	private QAFWebElement returnflightName;
	
	@FindBy(locator="flight.roundtrip.book.price.departflight")
	private QAFWebElement departFlightPrice;
	
	@FindBy(locator="flight.roundtrip.book.price.returnflight")
	private QAFWebElement returnFlightPrice;
	
	
	public QAFWebElement getDepartFlightRadioBtn() {
		return departFlightRadioBtn;
	}
	public QAFWebElement getReturnflightRadioBtn() {
		return returnflightRadioBtn;
	}
	public QAFWebElement getDepartFlightName() {
		return departFlightName;
	}
	public QAFWebElement getReturnflightName() {
		return returnflightName;
	}
	public QAFWebElement getDepartFlightPrice() {
		return departFlightPrice;
	}
	public QAFWebElement getReturnFlightPrice() {
		return returnFlightPrice;
	}
	
	
	
	
	
}
