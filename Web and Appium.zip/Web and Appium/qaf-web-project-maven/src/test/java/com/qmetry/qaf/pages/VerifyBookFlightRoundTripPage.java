package com.qmetry.qaf.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.beans.VerifyBookFlightRoundTripBeans;
import com.qmetry.qaf.components.VerifyBookFlightRoundTripComponents;

public class VerifyBookFlightRoundTripPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	
		

	@FindBy(locator="flight.roundtrip.book.roundtrip")
	private QAFWebElement tripType;
	@FindBy(locator="flight.roundtrip.book.passcount")
	private QAFWebElement passengerCount;
	@FindBy(locator="flight.roundtrip.book.departfrm")
	private QAFWebElement deptFrom;
	@FindBy(locator="flight.roundtrip.book.fromday")
	private QAFWebElement fromDate;
	@FindBy(locator="flight.roundtrip.book.arrivingin")
	private QAFWebElement arrival;
	@FindBy(locator="flight.roundtrip.book.returningday")
	private QAFWebElement toDate;
	@FindBy(locator="flight.roundtrip.book.returningMonth")
	private QAFWebElement toMonth;
	@FindBy(locator="flight.roundtrip.book.FlightFindcontinuelink")
	private QAFWebElement fndFlightContBtn;
	
	@FindBy(locator="flight.roundtrip.book.list.departflightdetails")
    private List<VerifyBookFlightRoundTripComponents> departflightdetails;
	
	@FindBy(locator="flight.roundtrip.book.list.returnflightdetails")
    private List<VerifyBookFlightRoundTripComponents> returnflightdetails;
	
	@FindBy(locator="flight.roundtrip.book.findFlightContinueBtn")
	private QAFWebElement selFlightContBtn;
	@FindBy(locator="flight.roundtrip.book.securePurchaseBtn")
	private QAFWebElement securePurchaseBtn;
	
	@FindBy(locator="flight.roundtrip.book.conformation.departingFromtoTo")
	private QAFWebElement conformationPageDepartingFromtoToFlights;
	@FindBy(locator="flight.roundtrip.book.conformation.departingFlightName")
	private QAFWebElement conformationPageDepartingFlightName;
	
	@FindBy(locator="flight.roundtrip.book.conformation.returningFromtoTo")
	private QAFWebElement conformationPageReturningFromtoToFlights;
	@FindBy(locator="flight.roundtrip.book.conformation.returningFlightName")
	private QAFWebElement conformationPageReturningFlightName;
	@FindBy(locator="flight.roundtrip.book.conformation.passengerCount")
	private QAFWebElement conformationPagepassengerCount;
	@FindBy(locator="flight.roundtrip.book.conformation.taxes")
	private QAFWebElement conformationPageTaxes;
	@FindBy(locator="flight.roundtrip.book.conformation.totalPrice")
	private QAFWebElement conformationPageTotalPrice;
	
	
	public QAFWebElement getTripType() {
		return tripType;
	}
	public QAFWebElement getPassengerCount() {
		return passengerCount;
	}
	public QAFWebElement getDeptFrom() {
		return deptFrom;
	}
	public QAFWebElement getFromDate() {
		return fromDate;
	}
	public QAFWebElement getArrival() {
		return arrival;
	}
	public QAFWebElement getToDate() {
		return toDate;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getToMonth() {
		return toMonth;
	}
	public List<VerifyBookFlightRoundTripComponents> getDepartflightdetails() {
		return departflightdetails;
	}
	public List<VerifyBookFlightRoundTripComponents> getReturnflightdetails() {
		return returnflightdetails;
	}
	
	public QAFWebElement getSelFlightContBtn() {
		return selFlightContBtn;
	}
	public QAFWebElement getSecurePurchaseBtn() {
		return securePurchaseBtn;
	}
	
	
	
	
	public QAFWebElement getConformationPageDepartingFromtoToFlights() {
		return conformationPageDepartingFromtoToFlights;
	}
	public QAFWebElement getConformationPageDepartingFlightName() {
		return conformationPageDepartingFlightName;
	}
	public QAFWebElement getConformationPageReturningFromtoToFlights() {
		return conformationPageReturningFromtoToFlights;
	}
	public QAFWebElement getConformationPageReturningFlightName() {
		return conformationPageReturningFlightName;
	}
	
	public QAFWebElement getConformationPagepassengerCount() {
		return conformationPagepassengerCount;
	}
	public QAFWebElement getConformationPageTaxes() {
		return conformationPageTaxes;
	}
	public QAFWebElement getConformationPageTotalPrice() {
		return conformationPageTotalPrice;
	}
	
	
	
	
	public void findFlight(String tripType,String passCount, String dptFrom,String arrivingIn)
	{
		if(!getTripType().isSelected())
		getTripType().click();
		Select count=new Select(getPassengerCount());
		count.selectByVisibleText(passCount);
		Select deptFrom=new Select(getDeptFrom());
		deptFrom.selectByVisibleText(dptFrom);
		//Below statements will call increseDate() to Next Day from Current Date
		Select fDate=new Select(getFromDate());
		fDate.selectByVisibleText(increseDate("1"));
		Select arriving=new Select(getArrival());
		arriving.selectByVisibleText(arrivingIn);
		//Below statements will call increaseArrivalDate() and takes departure date and add 5 days after departure
		Select aDate=new Select(getToDate());
		aDate.selectByVisibleText(increaseArrivalDate(departureDate));
		
		Select toMonth=new Select(getToMonth());
		toMonth.selectByValue(increaseMonth(departureDate));
		Validator.assertThat("Find a Flight Page",driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		getFndFlightContBtn().click();
		Validator.assertThat("Select a Flight Page",driver.getTitle(),Matchers.containsString("Select a Flight: Mercury Tours"));
		
	}
		
		public void selectDepartFlight(List<VerifyBookFlightRoundTripComponents> departFlight, String flightname) {

				for (VerifyBookFlightRoundTripComponents Dflight : departFlight) {
					if (Dflight.getDepartFlightName().getText().equals(flightname)) {
						Dflight.getDepartFlightRadioBtn().click();
						Reporter.logWithScreenShot("The Deparflight with name  " + Dflight.getDepartFlightName().getText() + "has been selected");
					}
				}
			} 
		VerifyBookFlightRoundTripComponents Rflight = null;
		public void selectReturnFlight(List<VerifyBookFlightRoundTripComponents> returnflight, String flightname) {

			for (VerifyBookFlightRoundTripComponents Rflight : returnflight) {
				if (Rflight.getReturnflightName().getText().equals(flightname)) {
					Rflight.getReturnflightRadioBtn().click();
					Reporter.logWithScreenShot("The Return flight with name  " + Rflight.getReturnflightName().getText() + "has been selected");
				}
			}
		} 
		
		public void fillBookFlightForm()
		{
			getSelFlightContBtn().click();
			Validator.assertThat("Book a Flight Page",driver.getTitle(),Matchers.containsString("Book a Flight: Mercury Tours"));
			VerifyBookFlightRoundTripBeans bookFlightForm= new VerifyBookFlightRoundTripBeans();
			bookFlightForm.fillFromConfig("data.flightdetails");
			bookFlightForm.fillUiElements();
			getSecurePurchaseBtn().click();
			Validator.assertThat("Flight Conformation Page",driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		}
		
		
		public void verifyConformationPageDetails(String departCity,String arrivalCity, String departFlightName, String departclass,String departFlightPrice, String returnFlightName,String returnClass,String returnFlightPrice,String passengerCount,String taxes,String totalPrice )
		{	//Departing Confirmation Details
			String departing=departCity+" to "+arrivalCity;
			Validator.verifyThat("Departing flight details for Portland to New York",getConformationPageDepartingFromtoToFlights().getText(),Matchers.containsString(departing));
			Validator.verifyThat("Departing flight name",getConformationPageDepartingFlightName().getText(),Matchers.containsString(departFlightName));
			Validator.verifyThat("Departing Flight Class",getConformationPageDepartingFlightName().getText(),Matchers.containsString(departclass));
			Validator.verifyThat("Departing Flight Price",getConformationPageDepartingFlightName().getText(),Matchers.containsString(departFlightPrice));
			//Returning Confirmation Details
			String returning=arrivalCity+" to "+departCity;
			Validator.verifyThat("Returning flight details for New York to Portland",getConformationPageReturningFromtoToFlights().getText(),Matchers.containsString(returning));
			Validator.verifyThat("Returning flight name",getConformationPageReturningFlightName().getText(),Matchers.containsString(returnFlightName));
			Validator.verifyThat("Returning Flight Class",getConformationPageReturningFlightName().getText(),Matchers.containsString(returnClass));
			Validator.verifyThat("Returning Flight Price",getConformationPageReturningFlightName().getText(),Matchers.containsString(returnFlightPrice));
			
			Validator.verifyThat("Number of passengers",getConformationPagepassengerCount().getText(),Matchers.containsString(passengerCount));
			Validator.verifyThat("Taxes",getConformationPageTaxes().getText(),Matchers.containsString(taxes));
			Validator.verifyThat("Tatal Price",getConformationPageTotalPrice().getText(),Matchers.containsString(totalPrice));
		}
	
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM");
	Date date = new Date();
	Calendar calender = Calendar.getInstance();
	String departureDate;
	String arrivalDate;
	String month;
	
	public String increseDate(String deptFromDate)
	{
		calender.setTime(date);
		int calculate = Integer.parseInt(deptFromDate);
		calender.add(Calendar.DATE,calculate);
		date = calender.getTime();
		departureDate = formatter.format(date).substring(0, 2);
		departureDate=StringUtils.stripStart(departureDate,"0");
		return departureDate;
	}

	public String increaseArrivalDate(String departureDate)
	{
		calender.setTime(date);
		calender.add(Calendar.DATE,5);
		date = calender.getTime();
		arrivalDate = formatter.format(date).substring(0, 2);
		arrivalDate=StringUtils.stripStart(arrivalDate,"0");
		return arrivalDate;
	}
	public String increaseMonth(String departureDate)
	{
		calender.setTime(date);
		calender.add(Calendar.DATE,5);
		date = calender.getTime();
		month = formatter.format(date).substring(3, 5);
		month=StringUtils.stripStart(month,"0");
		return month;
	}


	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
	}

}
