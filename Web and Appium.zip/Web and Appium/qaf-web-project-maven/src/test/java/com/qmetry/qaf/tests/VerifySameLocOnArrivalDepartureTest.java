package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.VerifySameLocOnArrivalDeparturePage;
public class VerifySameLocOnArrivalDepartureTest extends WebDriverTestBase{
	
	VerifySameLocOnArrivalDeparturePage location= new VerifySameLocOnArrivalDeparturePage();
	
	@BeforeTest
	public void login()
	{
		location.launchPage(null);	
		location.verifyLoginPageTitle();
		location.login();
	}
	
	@QAFDataProvider(key="findflight.data")
	@Test
	public void sameLocationArrivalDept(Map<String,String> data)
	{
		location.findFlight(data.get("passenger"), data.get("deptFrom"),data.get("deptDate") ,data.get("arrivingIn"));
		
			
	}

}
