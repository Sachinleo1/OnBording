package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;
import org.testng.Reporter;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;

public class SignInPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	
		
	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	

	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	

	public void verifyLoginPageTitle(){
	Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
	}
	public void loginSuccess(){
	Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
	}
	
	public void signIn(String validUserName, String validPwd)
	{
		getUserName().sendKeys(validUserName);
		getPassword().sendKeys(validPwd);
		getSignIn().click();
		loginSuccess();
		Reporter.log("Loging in Success",true);
	}
	public void invalidSignIn(String invalidUserName, String invalidPwd)
	{
		Validator.assertThat("LogIn Page",driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		getUserName().sendKeys(invalidUserName);
		getPassword().sendKeys(invalidPwd);
		getSignIn().click();	
		Validator.assertThat("LogIn failed Page",driver.getTitle(),Matchers.containsString("Sign-on: Mercury Tours"));
		Reporter.log("LogIn Failed");
		
		
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}


}
