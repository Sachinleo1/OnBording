package com.qmetry.qaf.tests;

import java.util.Map;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.FieldValidationOnBookFlightPage;

public class FieldValidationOnBookFlightTest extends WebDriverTestBase {
	
	FieldValidationOnBookFlightPage fieldValidate=new FieldValidationOnBookFlightPage();
	
	
	
	@BeforeTest
	public void login()
	{
		fieldValidate.launchPage(null);	
		fieldValidate.verifyLoginPageTitle();
		fieldValidate.login();
	}
	
	@QAFDataProvider(key="bookflight.passenger")
	@Test
	public void fieldValidationBookFlightPage(Map<String,String> name){
		fieldValidate.validateBookFlight(name.get("first_name"),name.get("last_name"));
	}

}
