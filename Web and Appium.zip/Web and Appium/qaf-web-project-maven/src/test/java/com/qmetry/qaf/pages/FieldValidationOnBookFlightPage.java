package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class FieldValidationOnBookFlightPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	@FindBy(locator="field.validate.bookflight.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	@FindBy(locator="field.validate.bookflight.selectFlightContinueBtn")
	private QAFWebElement selFlightContBtn;
	@FindBy(locator="field.validate.bookflight.securePurchaseBtn")
	private QAFWebElement securePurchaseBtn;
	@FindBy(locator="back.to.flight.backtoflightBtn")
	private QAFWebElement backToFlightBtn;
	@FindBy(locator="field.validate.bookflight.first_name")
	private QAFWebElement first_name;
	@FindBy(locator="field.validate.bookflight.last_name")
	private QAFWebElement last_name;
	
	
	
	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getSelFlightContBtn() {
		return selFlightContBtn;
	}
	public QAFWebElement getSecurePurchaseBtn() {
		return securePurchaseBtn;
	}
	public QAFWebElement getBackToFlightBtn() {
		return backToFlightBtn;
	}
	public QAFWebElement getFirst_name() {
		return first_name;
	}
	public QAFWebElement getLast_name() {
		return last_name;
	}
	
	public void verifyLoginPageTitle(){
		Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		}
	
	public void login(){
			getUserName().sendKeys(ConfigurationManager.getBundle().getString("test.user.name"));
			getPassword().sendKeys(ConfigurationManager.getBundle().getString("test.pass.password"));
			getSignIn().click();
			Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		}
	public void validateBookFlight(String first_name, String last_name)
	{
		getFndFlightContBtn().click();
		getSelFlightContBtn().click();
		Validator.assertThat("Book a Flight Page",driver.getTitle(),Matchers.containsString("Book a Flight: Mercury Tours"));
		getFirst_name().sendKeys(first_name);
		Reporter.log(first_name);
		getLast_name().sendKeys(last_name);
		Reporter.log(last_name);
		getSecurePurchaseBtn().click();
		Validator.assertThat("Flight Conformation Page",driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		getBackToFlightBtn().click();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	driver.get("/");
		
	}

}
