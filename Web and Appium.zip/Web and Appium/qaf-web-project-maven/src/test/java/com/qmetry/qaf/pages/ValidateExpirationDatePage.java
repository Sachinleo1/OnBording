package com.qmetry.qaf.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.hamcrest.Matchers;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class ValidateExpirationDatePage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	VerifyBackToFlightPage flight= new VerifyBackToFlightPage();
	@FindBy(locator="validate.cardExpiration.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	@FindBy(locator="validate.cardExpiration.selectFlightContinueBtn")
	private QAFWebElement selectFlightContinueBtn;
	@FindBy(locator="validate.cardExpiration.month")
	private QAFWebElement cardExpireMonth;
	@FindBy(locator="validate.cardExpiration.securePurchaseBtn")
	private QAFWebElement securePurchaseBtn;
	@FindBy(locator="validate.cardExpiration.backtoflightBtn")
	private QAFWebElement backtoflightBtn;

	
	public VerifyBackToFlightPage getFlight() {
		return flight;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getSelectFlightContinueBtn() {
		return selectFlightContinueBtn;
	}
	public QAFWebElement getCardExpireMonth() {
		return cardExpireMonth;
	}
	public QAFWebElement getSecurePurchaseBtn() {
		return securePurchaseBtn;
	}
	public QAFWebElement getBacktoflightBtn() {
		return backtoflightBtn;
	}
	
	public void validateExpirationDate(String expireDate)
	{
	Validator.assertThat("Find a Flight Page",driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
	getFndFlightContBtn().click();
	Validator.assertThat("Select a Flight Page",driver.getTitle(),Matchers.containsString("Select a Flight: Mercury Tours"));
	getSelectFlightContinueBtn().click();
	
	SimpleDateFormat formatter = new SimpleDateFormat("MM");
	Date date = new Date();
	Calendar c = Calendar.getInstance();
	
	switch(expireDate)
	{
	case "past date":
		c.setTime(date);
		c.add(Calendar.MONTH,-1);
		date = c.getTime();
		String past = formatter.format(date);
		Select pastDate=new Select(getCardExpireMonth());
		pastDate.selectByVisibleText(past);
		Reporter.log("Past Date is:"+past);
		break;
	
	case "present date":
		date = c.getTime();
		String present = formatter.format(date);
		Select presentDate=new Select(getCardExpireMonth());
		presentDate.selectByVisibleText(present);
		Reporter.log("Present Date is:"+present);
		break;
		
	case "no date": break;
	default: break;
		
	}	
	Validator.verifyThat("Book a Flight Page", driver.getTitle(),Matchers.containsString("Book a Flight: Mercury Tours"));
	getSecurePurchaseBtn().click();
	Validator.verifyThat("Flight Conformation Page", driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
	getBacktoflightBtn().click();
	Validator.verifyThat("Back to Flight Finder Page", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));

	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
