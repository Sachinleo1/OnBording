package com.qmetry.qaf.beans;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.ui.annotations.UiElement.Type;

public class VerifyBookFlightRoundTripBeans extends BaseFormDataBean{
	
	@UiElement(fieldLoc = "flight.roundtrip.book.firstName", order=1)
	public String firstName;
	@UiElement(fieldLoc = "flight.roundtrip.book.lastName", order=2)
	public String lastName;
	@UiElement(fieldLoc = "flight.roundtrip.book.cardNo", order=3)
	public String cardNo;
	@UiElement(fieldLoc = "flight.roundtrip.book.cardExpireMonth",fieldType=Type.selectbox, order=4)
	public String cardExpireMonth;
	@UiElement(fieldLoc = "flight.roundtrip.book.cardExpireYear",fieldType=Type.selectbox, order=12)
	public String cardExpireYear;
	@UiElement(fieldLoc = "flight.roundtrip.book.address", order=5)
	public String address;
	@UiElement(fieldLoc = "flight.roundtrip.book.city", order=6)
	public String city;
	@UiElement(fieldLoc = "flight.roundtrip.book.state", order=7)
	public String state;
	@UiElement(fieldLoc = "flight.roundtrip.book.postalCode", order=8)
	public String postalCode;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getCardExpireMonth() {
		return cardExpireMonth;
	}
	public void setCardExpireMonth(String cardExpireMonth) {
		this.cardExpireMonth = cardExpireMonth;
	}
	public String getCardExpireYear() {
		return cardExpireYear;
	}
	public void setCardExpireYear(String cardExpireYear) {
		this.cardExpireYear = cardExpireYear;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String postalCode() {
		return postalCode;
	}
	public void setPostal_code(String postalCode) {
		this.postalCode = postalCode;
	}
	
	
	
	
}
