package com.qmetry.qaf.tests;


import org.testng.annotations.Test;

import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.LogoutPage;

public class LogoutCheckTest extends WebDriverTestBase {

	
	@Test
	public void logoutTest()
	{
		LogoutPage logout = new LogoutPage();
		logout.launchPage(null);
		logout.verifyLogout();
		
	}
}
