package com.qmetry.qaf.tests;

import org.testng.annotations.Test;

import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.VerifyPopUpPage;

public class VerifyPopUpTest extends WebDriverTestBase {
	
	@Test
	public void verifyPopUp()
	{
		VerifyPopUpPage popUp=new VerifyPopUpPage();
		popUp.launchPage(null);
		popUp.verifyLoginPageTitle();
		popUp.login();
		popUp.verifyPopUpMsg();
	}

}
