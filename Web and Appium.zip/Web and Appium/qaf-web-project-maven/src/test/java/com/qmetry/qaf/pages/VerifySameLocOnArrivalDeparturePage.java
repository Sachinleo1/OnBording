package com.qmetry.qaf.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;

public class VerifySameLocOnArrivalDeparturePage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	
	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	@FindBy(locator="validate.sameLocation.tripType")
	private QAFWebElement tripType;
	@FindBy(locator="validate.sameLocation.passCount")
	private QAFWebElement passengerCount;
	@FindBy(locator="validate.sameLocation.deptFrom")
	private QAFWebElement deptFrom;
	@FindBy(locator="validate.sameLocation.fromDate")
	private QAFWebElement fromDate;
	@FindBy(locator="validate.sameLocation.arrival")
	private QAFWebElement arrival;
	@FindBy(locator="validate.sameLocation.toDate")
	private QAFWebElement toDate;
	@FindBy(locator="validate.sameLocation.locationNameOnflightPage")
	private QAFWebElement verifySameLocation;
	@FindBy(locator="validate.sameLocation.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	
	
	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getTripType() {
		return tripType;
	}
	public QAFWebElement getPassengerCount() {
		return passengerCount;
	}
	public QAFWebElement getDeptFrom() {
		return deptFrom;
	}
	public QAFWebElement getFromDate() {
		return fromDate;
	}
	public QAFWebElement getArrival() {
		return arrival;
	}
	public QAFWebElement getToDate() {
		return toDate;
	}
	public QAFWebElement getVerifySameLocation() {
		return verifySameLocation;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	
	
	
	
	public void verifyLoginPageTitle(){
		Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		}
	
	public void login(){
			getUserName().sendKeys(ConfigurationManager.getBundle().getString("test.user.name"));
			getPassword().sendKeys(ConfigurationManager.getBundle().getString("test.pass.password"));
			getSignIn().click();
			Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		}
	
	
	public void findFlight(String passCount, String dptFrom, String deptFromDate,String arrivingIn)
	{
		if(!getTripType().isSelected())
		getTripType().click();
		Select count=new Select(getPassengerCount());
		count.selectByVisibleText(passCount);
		Select deptFrom=new Select(getDeptFrom());
		deptFrom.selectByVisibleText(dptFrom);
		//Below statements will call increseDate() to Next Day from Current Date
		Select fDate=new Select(getFromDate());
		fDate.selectByVisibleText(increseDate(deptFromDate));
		Select arriving=new Select(getArrival());
		arriving.selectByVisibleText(arrivingIn);
		//Below statements will call increaseArrivalDate() and takes departure date and add 5 days after departure
		Select aDate=new Select(getToDate());
		aDate.selectByVisibleText(increaseArrivalDate(departureDate));
		Validator.assertThat("Find a Flight Page",driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		String msg_name=deptFrom.getFirstSelectedOption().getText()+" "+"to"+" "+arriving.getFirstSelectedOption().getText();
		getFndFlightContBtn().click();
		Validator.assertThat("Select a Flight Page",driver.getTitle(),Matchers.containsString("Select a Flight: Mercury Tours"));
		Validator.verifyThat("Depart flight details for London to London and Return flight details for London to London",getVerifySameLocation().getText(),Matchers.containsString(msg_name));
	}
	
	
	
	SimpleDateFormat formatter = new SimpleDateFormat("dd");
	Date date = new Date();
	Calendar calender = Calendar.getInstance();
	String departureDate;
	String arrivalDate;
	
	public String increseDate(String deptFromDate)
	{
		calender.setTime(date);
		int calculate = Integer.parseInt(deptFromDate);
		calender.add(Calendar.DATE,calculate);
		date = calender.getTime();
		departureDate = formatter.format(date);
		departureDate=StringUtils.stripStart(departureDate,"0");
		return departureDate;
	}

	public String increaseArrivalDate(String departureDate)
	{
		calender.setTime(date);
		calender.add(Calendar.DATE,5);
		date = calender.getTime();
		arrivalDate = formatter.format(date);
		arrivalDate=StringUtils.stripStart(arrivalDate,"0");
		return arrivalDate;
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
