package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.ValidateCardNoFieldPage;

public class ValidateCardNoFieldTest extends WebDriverTestBase {
	ValidateCardNoFieldPage card= new ValidateCardNoFieldPage();
	
	@BeforeTest
	public void login()
	{
		card.launchPage(null);	
		card.verifyLoginPageTitle();
		card.login();
	}
	
	@QAFDataProvider(key="validateCard.number")
	@Test
	public void validateCardNumber(Map<String,String> number){
	card.validateCardNumberField(number.get("cardNo"));
	}

}
