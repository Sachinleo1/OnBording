package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.SignInPage;

public class SignInTest extends WebDriverTestBase {
	
	SignInPage login=new SignInPage();
	
	
	@Test(description="Valid loging test", priority =1)
	public void validLogin()
	{
		login.launchPage(null);
		login.verifyLoginPageTitle();
		login.signIn(ConfigurationManager.getBundle().getString("test.user.name"), ConfigurationManager.getBundle().getString("test.pass.password"));		
		
	}
	
	@QAFDataProvider(key="login.user")
	@Test(description="InValid loging test", priority =2)
	public void inValidLogin(Map<String,String> invalidData)
	{
		login.launchPage(null);
		login.invalidSignIn(invalidData.get("user_name"), invalidData.get("password"));
			
	}
}
