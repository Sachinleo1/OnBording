package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;

public class VerifyContactPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	
		
	@FindBy(locator="contact.check.link")
	private QAFWebElement contactLink;
	
	@FindBy(locator="contact.underconstruction.msg")
	private QAFWebElement UnderConMsg;
	
	@FindBy(locator="contact.backtohome.link")
	private QAFWebElement back2home;
	

	public QAFWebElement getContactLink() {
		return contactLink;
	}
	public QAFWebElement getUnderConMsg() {
		return UnderConMsg;
	}
	public QAFWebElement getBack2home() {
		return back2home;
	}
	
	
	public void verifyContLink() {
		Validator.assertTrue(getContactLink().isPresent(), "Contact link Not is present", "Contact link is present");
	}
	
	public void underConMsg()
	{
		Validator.assertTrue(getUnderConMsg().isDisplayed(), "Under Construction Message Not is Displayed in the page", "Under Construction Message is Displayed in the Page");
	}
	
	public void homepage()
	{
		Validator.verifyThat("Home page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}
}
