package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.SignInPage;
import com.qmetry.qaf.pages.VerifyBookFlightRoundTripPage;

public class VerifyBookFlightRoundTripTest extends WebDriverTestBase {
	
	
SignInPage login=new SignInPage();
	
	@BeforeTest
	public void validLogin()
	{
		login.launchPage(null);
		login.verifyLoginPageTitle();
		login.signIn(ConfigurationManager.getBundle().getString("test.user.name"), ConfigurationManager.getBundle().getString("test.pass.password"));		
		
	}
	
		
	@QAFDataProvider(key="data.flightdetails")
	@Test(priority=1)
	public void bookFlightRoundTrip(Map<String,String> data)
	{
		VerifyBookFlightRoundTripPage roundTrip=new VerifyBookFlightRoundTripPage();
		roundTrip.findFlight(data.get("tripType"),data.get("passenger"),data.get("departCity"),data.get("arriveCity"));//"Pangaea Airlines 362"
		roundTrip.selectDepartFlight(roundTrip.getDepartflightdetails(),data.get("departFlight"));
		roundTrip.selectReturnFlight(roundTrip.getReturnflightdetails(),data.get("returnFlight"));
		roundTrip.fillBookFlightForm();
		roundTrip.verifyConformationPageDetails(data.get("departCity"),data.get("arriveCity"),data.get("departFlight"),data.get("class"),data.get("departprice"),data.get("returnFlight"),data.get("class"),data.get("returnprice"),data.get("passenger"),data.get("taxes"),data.get("totalprice"));
	
		
			
	}
}
