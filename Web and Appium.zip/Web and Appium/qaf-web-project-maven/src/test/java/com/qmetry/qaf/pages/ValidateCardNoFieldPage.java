package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class ValidateCardNoFieldPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	@FindBy(locator="validate.cardNumber.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	@FindBy(locator="validate.cardNumber.selectFlightContinueBtn")
	private QAFWebElement selFlightContBtn;
	@FindBy(locator="validate.cardNumber.creditCardNo")
	private QAFWebElement cardNumber;
	@FindBy(locator="field.validate.bookflight.securePurchaseBtn")
	private QAFWebElement securePurchaseBtn;
	@FindBy(locator="back.to.flight.backtoflightBtn")
	private QAFWebElement backToFlightBtn;

	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getSelFlightContBtn() {
		return selFlightContBtn;
	}
	public QAFWebElement getCardNumber() {
		return cardNumber;
	}
	public QAFWebElement getSecurePurchaseBtn() {
		return securePurchaseBtn;
	}
	public QAFWebElement getBackToFlightBtn() {
		return backToFlightBtn;
	}
	
	
	public void verifyLoginPageTitle(){
		Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		}
	
	public void login(){
			getUserName().sendKeys(ConfigurationManager.getBundle().getString("test.user.name"));
			getPassword().sendKeys(ConfigurationManager.getBundle().getString("test.pass.password"));
			getSignIn().click();
			Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		}
	public void validateCardNumberField(String cardNo)
	{
		getFndFlightContBtn().click();
		getSelFlightContBtn().click();
		Validator.assertThat("Book a Flight Page",driver.getTitle(),Matchers.containsString("Book a Flight: Mercury Tours"));
		getCardNumber().sendKeys(cardNo);
		Reporter.log("Entered card Number is "+getCardNumber().getAttribute("value")+"  "+"Actual card number is"+ cardNo);
		getSecurePurchaseBtn().click();
		Validator.assertThat("Flight Conformation Page",driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		getBackToFlightBtn().click();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
