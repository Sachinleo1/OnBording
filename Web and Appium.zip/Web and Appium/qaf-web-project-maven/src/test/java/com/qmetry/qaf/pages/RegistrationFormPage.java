package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;
import com.qmetry.qaf.beans.RegistrationFormBeans;

public class RegistrationFormPage  extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator="registeration.form.registerlink")
	private QAFWebElement register_link;
	
	@FindBy(locator="registeration.form.submitbtn")
	private QAFExtendedWebElement submit_btn;
	
	@FindBy(locator="registeration.form.success_msg")
	private QAFExtendedWebElement success_msg;
	
	
	public QAFWebElement getRegister_link() {
		return register_link;
	}
	
	public QAFExtendedWebElement getSubmit_btn() {
		return submit_btn;
	}
	
	

	public QAFExtendedWebElement getSuccess_msg() {
		return success_msg;
	}

	public void fillData()
	{
		Validator.verifyThat("Home page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
		getRegister_link().click();
		RegistrationFormBeans baseDataBean = new RegistrationFormBeans ();
		baseDataBean.fillFromConfig("form.registration.user");
		baseDataBean.fillUiElements();
		getSubmit_btn().click();
		String msg_name="Dear " + baseDataBean.first_name +" "+ baseDataBean.last_name+",";
		Validator.verifyThat("Registration Successfull",getSuccess_msg().getText(),Matchers.containsString(msg_name));
		Validator.verifyThat("Registration Successfull", driver.getTitle(),Matchers.containsString("Register: Mercury Tours"));
		
	}


	


	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.get("/");
		
	}

}
