package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.SignInPage;
import com.qmetry.qaf.pages.VerifyDifferentDepatureArrivalDatePage;

public class VerifyDifferentDepatureArrivalDateTest extends WebDriverTestBase {
	

	
	@BeforeTest
	public void validLogin()
	{ 	
		SignInPage login=new SignInPage();
		login.launchPage(null);
		login.verifyLoginPageTitle();
		login.signIn(ConfigurationManager.getBundle().getString("test.user.name"), ConfigurationManager.getBundle().getString("test.pass.password"));		
		
	}
	
	
	
	@QAFDataProvider(key="depatureArriving.date")
	@Test
	public void sameLocationArrivalDeptDate(Map<String,String> data)
	{  
		VerifyDifferentDepatureArrivalDatePage departureArrivalDate= new VerifyDifferentDepatureArrivalDatePage();
		departureArrivalDate.findFlight(data.get("deptDate"),data.get("toDate"));		
	}


}
