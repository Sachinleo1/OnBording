package com.qmetry.qaf.tests;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.HomePage;

public class HomePageTest extends WebDriverTestBase{
	
	HomePage home;
	@Test
	public void verify_components()
	{
		home=new HomePage();
		home.launchPage(null);
		home.verifyTitle();
		home.verifyComponents();
	}
	

}
