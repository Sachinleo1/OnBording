package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;


public class HomePage extends WebDriverBaseTestPage<WebDriverTestPage> {
	//Declaring components on left menu
	@FindBy(locator="homepage.home.link")
	private QAFWebElement homeLink;
	
	@FindBy(locator="homepage.flights.link")
	private QAFWebElement flightsLink;
	
	@FindBy(locator="homepage.hotels.link")
	private QAFWebElement hotelsLink;
	
	@FindBy(locator="homepage.carrents.link")
	private QAFWebElement carrentsLink;
	
	@FindBy(locator="homepage.cruises.link")
	private QAFWebElement cruisesLink;
	
	@FindBy(locator="homepage.destinations.link")
	private QAFWebElement destinationsLink;
	
	@FindBy(locator="homepage.vacations.link")
	private QAFWebElement vacationsLink;
	 
	
	//Declaring components on top menu
	@FindBy(locator="homepage.singon.link")
	private QAFWebElement singOnLink;
	
	@FindBy(locator="homepage.register.link")
	private QAFWebElement registerLink;
	
	@FindBy(locator="homepage.support.link")
	private QAFWebElement supportLink;
	
	@FindBy(locator="homepage.contact.link")
	private QAFWebElement contactLink;
	
	
	//Declaring other components in the page
	@FindBy(locator="homepage.featureDestination.img")
	private QAFWebElement featureDestinationImg;
	
	@FindBy(locator="homepage.findFlight.img")
	private QAFWebElement findFlightImg;
	
	@FindBy(locator="homepage.destination.img")
	private QAFWebElement destinationImg;
	
	@FindBy(locator="homepage.vacation.img")
	private QAFWebElement vacationImg;
	
	@FindBy(locator="homepage.register.img")
	private QAFWebElement registerImg;
	
	@FindBy(locator="homepage.links.img")
	private QAFWebElement linksImg;
	
	@FindBy(locator="homepage.specials.img")
	private QAFWebElement specialsImg;
	
	@FindBy(locator="homepage.tourtips.img")
	private QAFWebElement tourtipsImg;
	
	
	//Utilizing components on left menu
	public QAFWebElement getHomeLink() {
		return homeLink;
	}

	public QAFWebElement getFlightsLink() {
		return flightsLink;
	}

	public QAFWebElement getHotelsLink() {
		return hotelsLink;
	}

	public QAFWebElement getCarrentsLink() {
		return carrentsLink;
	}

	public QAFWebElement getCruisesLink() {
		return cruisesLink;
	}

	public QAFWebElement getDestinationsLink() {
		return destinationsLink;
	}
	public QAFWebElement getVacationsLink() {
		return vacationsLink;
	}
	
	//Utilizing components on Top menu
	public QAFWebElement getSingOnLink() {
		return singOnLink;
	}

	public QAFWebElement getRegisterLink() {
		return registerLink;
	}

	public QAFWebElement getSupportLink() {
		return supportLink;
	}

	public QAFWebElement getContactLink() {
		return contactLink;
	}
	
	//Utilizing other components in the page
		public QAFWebElement getFeatureDestinationImg() {
			return featureDestinationImg;
		}

		public QAFWebElement getFindFlightImg() {
			return findFlightImg;
		}

		public QAFWebElement getDestinationImg() {
			return destinationImg;
		}

		public QAFWebElement getVacationImg() {
			return vacationImg;
		}

		public QAFWebElement getRegisterImg() {
			return registerImg;
		}

		public QAFWebElement getLinksImg() {
			return linksImg;
		}

		public QAFWebElement getSpecialsImg() {
			return specialsImg;
		}

		public QAFWebElement getTourtipsImg() {
			return tourtipsImg;
		}
	
	
	
	
	//Verifying components on left menu
	public void verifyComponents() {
		
	
		
		
	Validator.assertTrue(getHomeLink().isPresent(), "Home link Not is present in left menu", "Home link is present in left menu");
	Validator.assertTrue(getFlightsLink().isPresent(), "Flights link is Not present in left menu", "Flights link is present in left menu");
	Validator.assertTrue(getHotelsLink().isPresent(), "Hotel link is Not present in left menu", "Hotel link is present in left menu");
	Validator.assertTrue(getCarrentsLink().isPresent(), "Carrents link is  Not present in left menu", "Carrents link is present in left menu");
	Validator.assertTrue(getCruisesLink().isPresent(), "Cruises link is Not present in left menu", "Cruises link is present in left menu");
	Validator.assertTrue(getDestinationsLink().isPresent(), "Destinations link is Not present in left menu", "Destinations link is present in left menu");
	Validator.assertTrue(getVacationsLink().isPresent(), "Vacation link is present in left menu","Vacation link is Not present in left menu");
	
	
	
	//Verifying components on Top menu
	
	Validator.assertTrue(getSingOnLink().isPresent(), "SignOn link Not is present in top menu", "SignOn link is present in top menu");
	Validator.assertTrue(getRegisterLink().isPresent(), "Register link Not is present in top menu", "Register link is present in top menu");
	Validator.assertTrue(getSupportLink().isPresent(), "Support link Not is present in top menu", "Support link is present in top menu");
	Validator.assertTrue(getContactLink().isPresent(), "Contact link Not is present in top menu", "Contact link is present in top menu");
	
	//Verifying other components in the page
	
	Validator.assertTrue(getFeatureDestinationImg().isDisplayed(), "Feature Destination Image Not is Displayed in the page", "Feature Destination Image is Displayed in the Page");
	Validator.assertTrue(getFindFlightImg().isDisplayed(), "Find Flight Image Not is Displayed in the page", "Find Flight Image is Displayed in the Page");
	Validator.assertTrue(getDestinationImg().isDisplayed(), "Destination Image Not is Displayed in the page", "Destination Image is Displayed in the Page");
	Validator.assertTrue(getVacationImg().isDisplayed(), "Vacation Image Not is Displayed in the page", "Vacation Image is Displayed in the Page");
	Validator.assertTrue(getRegisterImg().isDisplayed(), "Register Image Not is Displayed in the page", "Register Image is Displayed in the Page");
	Validator.assertTrue(getLinksImg().isDisplayed(), "Links Image Not is Displayed in the page", "Links Image is Displayed in the Page");
	Validator.assertTrue(getSpecialsImg().isDisplayed(), "Specials Image Not is Displayed in the page", "Specials Image is Displayed in the Page");
	Validator.assertTrue(getTourtipsImg().isDisplayed(), "Tour Tips Image Not is Displayed in the page", "Tour Tips Image is Displayed in the Page");
	
	
	}
	public void verifyTitle()
	{
		Validator.verifyThat("Home page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
	}
	
	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
		driver.get("/");
	//	driver.manage().window().maximize();
		
	}
	

}
