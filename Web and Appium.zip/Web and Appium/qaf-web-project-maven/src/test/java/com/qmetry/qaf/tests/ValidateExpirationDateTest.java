package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.SignInPage;
import com.qmetry.qaf.pages.ValidateExpirationDatePage;

public class ValidateExpirationDateTest extends WebDriverTestBase{
	
	
	SignInPage login=new SignInPage();
	
	@BeforeTest
	public void validLogin()
	{
		login.launchPage(null);
		login.verifyLoginPageTitle();
		login.signIn(ConfigurationManager.getBundle().getString("test.user.name"), ConfigurationManager.getBundle().getString("test.pass.password"));		
		
	}
	
	
	@QAFDataProvider(dataFile = "resources/data/ValidateExpirationDate.xls", sheetName = "Sheet1", key = "expirationDate")
	@Test(priority=1)
	public void validateExpirationDate(Map<String,String> data)
	{
		ValidateExpirationDatePage expirationDate=new ValidateExpirationDatePage();
		expirationDate.validateExpirationDate(data.get("date"));	
		
	}

}
