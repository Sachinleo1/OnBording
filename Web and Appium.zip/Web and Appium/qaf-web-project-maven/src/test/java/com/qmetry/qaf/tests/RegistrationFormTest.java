package com.qmetry.qaf.tests;

import java.util.Map;

import org.testng.annotations.Test;

import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.pages.RegistrationFormPage;
import com.qmetry.qaf.pages.RegistrationWithInvalidDataPage;

public class RegistrationFormTest extends WebDriverTestBase {
	
	@Test(description="Fill form with valida",priority=1)
	public void fillValidRegistrationForm()
	{
		RegistrationFormPage registrationForm=new RegistrationFormPage();
		registrationForm.launchPage(null);
		registrationForm.fillData();
	}
	
	@QAFDataProvider(dataFile = "resources/data/invalidRegData.xls", sheetName = "Sheet1", key = "test")
	@Test(description="Fill form with Invalida",priority=2)
	public void fillInvalidRegistrationForm(Map<String, String> data) {
		
		RegistrationWithInvalidDataPage registration = new RegistrationWithInvalidDataPage();
		registration.launchPage(null); 
		registration.fillData(data.get("user_name"), data.get("last_name"),data.get("phone_no"), data.get("email"));
	

		}
		
	}



