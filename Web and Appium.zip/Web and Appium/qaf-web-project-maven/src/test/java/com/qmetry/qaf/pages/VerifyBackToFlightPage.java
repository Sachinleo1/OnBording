package com.qmetry.qaf.pages;

import org.hamcrest.Matchers;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Validator;

public class VerifyBackToFlightPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	
		
	@FindBy(locator="signin.username.text")
	private QAFWebElement userName;
	@FindBy(locator="signin.pwd.text")
	private QAFWebElement password;
	@FindBy(locator="signin.login.btn")
	private QAFWebElement signIn;
	@FindBy(locator="back.to.flight.findFlightContinueBtn")
	private QAFWebElement fndFlightContBtn;
	@FindBy(locator="back.to.flight.selectFlightContinueBtn")
	private QAFWebElement selFlightContBtn;
	@FindBy(locator="back.to.flight.securePurchaseBtn")
	private QAFWebElement securePurchaseBtn;
	@FindBy(locator="back.to.flight.backtoflightBtn")
	private QAFWebElement backToFlightBtn;
	
	

	public QAFWebElement getUserName() {
		return userName;
	}
	public QAFWebElement getPassword() {
		return password;
	}
	public QAFWebElement getSignIn() {
		return signIn;
	}
	public QAFWebElement getFndFlightContBtn() {
		return fndFlightContBtn;
	}
	public QAFWebElement getSelFlightContBtn() {
		return selFlightContBtn;
	}
	public QAFWebElement getSecurePurchaseBtn() {
		return securePurchaseBtn;
	}
	public QAFWebElement getBackToFlightBtn() {
		return backToFlightBtn;
	}
	

	public void verifyLoginPageTitle(){
	Validator.verifyThat("Login page is displayed", driver.getTitle(),Matchers.containsString("Welcome: Mercury Tours"));
	}
	public void login(){
		//String usrName=ConfigurationManager.getBundle().getString("test.user.name"); 
		//String pwd=ConfigurationManager.getBundle().getString("test.pass.password"); 
		getUserName().sendKeys(ConfigurationManager.getBundle().getString("test.user.name"));
		getPassword().sendKeys(ConfigurationManager.getBundle().getString("test.pass.password"));
		getSignIn().click();
		Validator.verifyThat("Login Success", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
	}
	
	public void verifyFlightConformationPage(){
		//Validator.verifyThat("Flight Conformation Page", driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		getFndFlightContBtn().click();
		getSelFlightContBtn().click();
		getSecurePurchaseBtn().click();
		Validator.verifyThat("Flight Conformation Page", driver.getTitle(),Matchers.containsString("Flight Confirmation: Mercury Tours"));
		getBackToFlightBtn().click();
		Validator.verifyThat("Back to Flight Finder Page", driver.getTitle(),Matchers.containsString("Find a Flight: Mercury Tours:"));
		}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	driver.get("/");
		
	}
}
