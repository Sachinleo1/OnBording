import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.qmetry.qaf.automation.util.Reporter;

public class DateFind {

	public static void main(String[] args) {

//		SimpleDateFormat formatter = new SimpleDateFormat("dd");
//		Date date = new Date();
//		Calendar c = Calendar.getInstance();
//		c.setTime(date);
//		c.add(Calendar.DATE, -1);
//		date = c.getTime();
//		String actualDate = formatter.format(date);
//		int OnDay = Integer.parseInt(actualDate);
//		System.out.println(OnDay);
//		//return OnDay;
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM");
		Date date = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int calculate = Integer.parseInt("0");
		c.add(Calendar.DATE,calculate);
		date = c.getTime();
		String future = formatter.format(date).substring(0, 2);
		String month = formatter.format(date).substring(3, 5);
		Reporter.log("----"+future);
		System.out.println(future);
		System.out.println(month);
		//return future;
	}


		
 

}
 